FROST WATER — STARTER
A sound pack for Current (works.chamy.xyz/current), from CHAMY·XYZ, for the
Frost Electronic Music Ensemble, University of Miami. WATER, 8 November 2026.

TO OPEN IT: in Current, hold the speaker (or swipe down on Sound) and tap
"kit", then Import… and choose this zip. Or drop the zip on Current. Don't
unzip it. The eight sounds arrive with their roles already set.

WHAT IS IN IT (two sounds for each role; the ones marked * start switched on)
  touch    drip *            sample  samples/drip-1.wav, a new pitch each tap
           glass bowl        synth   hold to rub, let go to ring
  beat     low pulse *       sample  samples/low-pulse.wav, every beat
           rain tick *       synth   eighths, quietly
  bed      bowed glass *     sample  samples/bowed-glass-loop.wav, a 6 s seamless loop
           undertow          synth   dark noise, breathing
  pattern  drop ladder *     synth   off-beats, placed by the drawing
           drip pattern      sample  samples/drip-2.wav, with an echo

FILES
  pack.json         says what the zip is (kind surface.pack)
  instrument.json   the set (format instrument/1): "recipes" is the list of
                    sounds (format voice/0), "roles" says how each one plays
  samples/          48 kHz 16-bit WAV. One-shots peak at -1 dBFS; the loop
                    sits at about -18 LUFS so it stays under everything

The recordings were synthesized offline in Python (NumPy, SciPy): a water drop
after Kees van den Doel's bubble model (2004), glass modes 1 : 2.32 : 4.25, and
a sub pulse. Nothing in this pack was recorded from anyone or licensed.

License: CC BY 4.0. Use it, change it, share it; name CHAMY·XYZ.
The study guide: works.chamy.xyz/current/packs/
