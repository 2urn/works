TEMPLATE PACK FOR CURRENT
A skeleton to fill with your own sounds. It opens in Current as it is (the four
placeholder recordings are simple synthesized tones), so you can hear the roles
before you change anything.

  pack.json         what the zip is. Change "id" (lowercase, dashes) and "name".
  instrument.json   the set: "recipes" (one entry per sound) and "roles" (how
                    each plays: touch, beat, bed or pattern; on; level 0-2)
  samples/          your recordings. Replace my-touch.wav, my-beat.wav,
                    my-bed-loop.wav and my-pattern.wav with yours (same names),
                    or add new files and point a recipe's "sample" at them.

THE FASTEST WAY (no JSON at all): in Current open kit > Import… and pick your
audio files (or a folder of them). Each becomes a sound: shorter than 3 s a
one-shot (touch), 3 s or longer a loop (bed). Set the roles, then "Save as a
set": you get a pack zip like this one, ready to share.

FILES THAT WORK: wav, mp3, ogg, m4a/aac, flac (whatever your browser decodes;
wav and mp3 open everywhere). Mono or stereo, 44.1 or 48 kHz. Up to 12 MB and
45 seconds each, 60 MB per import.
LEVELS: one-shots peak at -1 dBFS; loops and beds about -18 to -16 LUFS so they
sit under the rest; nothing louder than -14 LUFS.
NAMES: lowercase, dashes, no spaces: rain-on-tin.wav, not "Rain on Tin (final).wav".

TO SHARE: zip the folder's contents (pack.json at the top of the zip, not inside
another folder; a single top folder is fine too) and send the .zip. Anyone opens
it in Current with kit > Import… or by dropping it on the stage. Nobody unzips.

The study guide, with the Ableton and Max export steps:
works.chamy.xyz/current/packs/
